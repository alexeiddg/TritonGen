# Cluster 1 Compile-Only Summary

## Run Shape

row_count: 45
actual_cells: 9
expected_row_count: 45
expected_conditions: ['G']
actual_conditions: ['G']
expected_grammar_variants: ['task_agnostic']
actual_grammar_variants: ['task_agnostic']
expected_kernel_classes: ['elementwise', 'reduction', 'matmul']
actual_kernel_classes: ['elementwise', 'matmul', 'reduction']
expected_dtypes: ['fp32', 'fp16', 'bf16']
actual_dtypes: ['bf16', 'fp16', 'fp32']
missing_cells: 0
unexpected_cells: 0
duplicate_identities: 0

## Compile Metrics

compile_success_scope: all_dtype_strict

| condition | grammar_variant | kernel_class | dtype | n | compile_success_scope | compile_successes | compile_failures | compile@1 | prompt_dtype_compile_successes | prompt_dtype_compile_failures | prompt_dtype_compile_success_rate | pass@1 | pass@5 | pass@10 | unique_solution_rate |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| G | task_agnostic | elementwise | bf16 | 5 | all_dtype_strict | 0 | 5 | 0.000000 | 4 | 1 | 0.800000 | 0.000000 | 0.000000 | NA | 0.600000 |
| G | task_agnostic | elementwise | fp16 | 5 | all_dtype_strict | 0 | 5 | 0.000000 | 1 | 4 | 0.200000 | 0.000000 | 0.000000 | NA | 1.000000 |
| G | task_agnostic | elementwise | fp32 | 5 | all_dtype_strict | 1 | 4 | 0.200000 | 1 | 4 | 0.200000 | 0.200000 | 1.000000 | NA | 1.000000 |
| G | task_agnostic | matmul | bf16 | 5 | all_dtype_strict | 0 | 5 | 0.000000 | 5 | 0 | 1.000000 | 0.000000 | 0.000000 | NA | 0.800000 |
| G | task_agnostic | matmul | fp16 | 5 | all_dtype_strict | 0 | 5 | 0.000000 | 3 | 2 | 0.600000 | 0.000000 | 0.000000 | NA | 1.000000 |
| G | task_agnostic | matmul | fp32 | 5 | all_dtype_strict | 5 | 0 | 1.000000 | 5 | 0 | 1.000000 | 1.000000 | 1.000000 | NA | 1.000000 |
| G | task_agnostic | reduction | bf16 | 5 | all_dtype_strict | 0 | 5 | 0.000000 | 1 | 4 | 0.200000 | 0.000000 | 0.000000 | NA | 1.000000 |
| G | task_agnostic | reduction | fp16 | 5 | all_dtype_strict | 0 | 5 | 0.000000 | 0 | 5 | 0.000000 | 0.000000 | 0.000000 | NA | 1.000000 |
| G | task_agnostic | reduction | fp32 | 5 | all_dtype_strict | 0 | 5 | 0.000000 | 0 | 5 | 0.000000 | 0.000000 | 0.000000 | NA | 1.000000 |

## Masked Token Rate

| condition | grammar_variant | kernel_class | dtype | n | mean | min | max |
| --- | --- | --- | --- | --- | --- | --- | --- |
| G | task_agnostic | elementwise | bf16 | 5 | 0.801309 | 0.797637 | 0.802908 |
| G | task_agnostic | elementwise | fp16 | 5 | 0.802150 | 0.798454 | 0.804065 |
| G | task_agnostic | elementwise | fp32 | 5 | 0.833538 | 0.797068 | 0.849194 |
| G | task_agnostic | matmul | bf16 | 5 | 0.913842 | 0.882495 | 0.924754 |
| G | task_agnostic | matmul | fp16 | 5 | 0.913240 | 0.901536 | 0.942040 |
| G | task_agnostic | matmul | fp32 | 5 | 0.934036 | 0.921838 | 0.953456 |
| G | task_agnostic | reduction | bf16 | 5 | 0.815950 | 0.771012 | 0.868285 |
| G | task_agnostic | reduction | fp16 | 5 | 0.804037 | 0.676440 | 0.931494 |
| G | task_agnostic | reduction | fp32 | 5 | 0.787365 | 0.636429 | 0.837255 |

## Compile Error Types

| condition | grammar_variant | kernel_class | dtype | compile_error_type | count |
| --- | --- | --- | --- | --- | --- |
| G | task_agnostic | elementwise | bf16 | RuntimeError | 5 |
| G | task_agnostic | elementwise | fp16 | RuntimeError | 5 |
| G | task_agnostic | elementwise | fp32 | CompilationError | 1 |
| G | task_agnostic | elementwise | fp32 | None | 1 |
| G | task_agnostic | elementwise | fp32 | RuntimeError | 3 |
| G | task_agnostic | matmul | bf16 | RuntimeError | 5 |
| G | task_agnostic | matmul | fp16 | RuntimeError | 5 |
| G | task_agnostic | matmul | fp32 | None | 5 |
| G | task_agnostic | reduction | bf16 | RuntimeError | 3 |
| G | task_agnostic | reduction | bf16 | SignatureError | 2 |
| G | task_agnostic | reduction | fp16 | RuntimeError | 2 |
| G | task_agnostic | reduction | fp16 | SignatureError | 3 |
| G | task_agnostic | reduction | fp32 | RuntimeError | 3 |
| G | task_agnostic | reduction | fp32 | SignatureError | 2 |

## Null-Hypothesis Report

- `kernel_class=elementwise`, `dtype=bf16`: comparison requires both baseline and G rows; observed 1 condition group(s).
- `kernel_class=elementwise`, `dtype=fp16`: comparison requires both baseline and G rows; observed 1 condition group(s).
- `kernel_class=elementwise`, `dtype=fp32`: comparison requires both baseline and G rows; observed 1 condition group(s).
- `kernel_class=matmul`, `dtype=bf16`: comparison requires both baseline and G rows; observed 1 condition group(s).
- `kernel_class=matmul`, `dtype=fp16`: comparison requires both baseline and G rows; observed 1 condition group(s).
- `kernel_class=matmul`, `dtype=fp32`: comparison requires both baseline and G rows; observed 1 condition group(s).
- `kernel_class=reduction`, `dtype=bf16`: comparison requires both baseline and G rows; observed 1 condition group(s).
- `kernel_class=reduction`, `dtype=fp16`: comparison requires both baseline and G rows; observed 1 condition group(s).
- `kernel_class=reduction`, `dtype=fp32`: comparison requires both baseline and G rows; observed 1 condition group(s).
