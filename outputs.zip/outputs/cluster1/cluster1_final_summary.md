# Cluster 1 Final Technical Summary

## A. Executive Summary

Cluster 1 tested the isolated G factor: grammar-constrained decoding for direct Triton kernel generation. The controlled comparison used the same model, prompt contract, temperature, token budget, seed schedule, kernel specs, and compile-only validator for baseline and G; the only intended experimental toggle was `grammar_active`.

The final controlled repaired comparison is:

| condition | compile successes | compile failures | compile@1 |
| --- | ---: | ---: | ---: |
| baseline | 0/180 | 180/180 | 0.000 |
| G | 180/180 | 0/180 | 1.000 |

G succeeded structurally in all scoped families: ReLU reached 60/60, Softmax reached 60/60, and GEMM reached 60/60 compile acceptance in the final controlled n=20 run. Baseline remained at 0/180, with all failures categorized as `SignatureError`.

The result matters because it shows that constrained decoding substantially repairs direct-Triton structural validity under an otherwise controlled generation setup. It does not establish numerical correctness, performance, memory safety, or broad KernelBench generalization.

## B. Experimental Design

Cluster 1 compares:

| condition | factor cell | grammar_active | meaning |
| --- | --- | ---: | --- |
| baseline | none | False | normal model generation with no grammar logits processor |
| G | G | True | same generation setup with grammar-constrained decoding active |

Controlled repaired comparison inputs:

| field | value |
| --- | --- |
| model | `Qwen/Qwen2.5-Coder-7B-Instruct-AWQ` |
| temperature | `0.2` |
| max_new_tokens | `512` |
| kernel classes | ReLU, Softmax, GEMM |
| dtypes | `fp32`, `fp16`, `bf16` |
| seeds | `0..19` per condition/kernel_class/dtype cell |
| compile backend | Modal GPU compile-only validation |
| generation backend | Modal generation |
| generation GPU | `L4` for both repaired baseline and final G artifacts |
| baseline artifact | `outputs/cluster1/baseline_repaired_l4_n20.jsonl` |
| G artifact | `outputs/cluster1/final_g_l4_n20.jsonl` |
| combined artifact | `outputs/cluster1/final_none_vs_g_l4_n20.jsonl` |

The compile metric is strict all-dtype compile acceptance. A row is successful only when the generated source passes canonical surface checks and Triton dummy-launch compilation across the validator's dtype/shape coverage. `pass@1`, `pass@5`, and `pass@10` are computed over compile success only; no numerical reference comparison is included.

The Modal generation class default may still appear as `L40S` in code or UI labels, but the frozen artifacts' sidecar metadata records the actual run override: `modal_generation_gpu == "L4"` and `infrastructure_failures == 0` for both the repaired baseline and final G runs.

## C. Controlled Comparison

| condition | kernel family | compile success | pass@1/pass@5/pass@10 |
| --- | --- | ---: | --- |
| baseline | ReLU | 0/60 | 0.000 / 0.000 / 0.000 |
| baseline | Softmax | 0/60 | 0.000 / 0.000 / 0.000 |
| baseline | GEMM | 0/60 | 0.000 / 0.000 / 0.000 |
| G | ReLU | 60/60 | 1.000 / 1.000 / 1.000 for all dtypes |
| G | Softmax | 60/60 | 1.000 / 1.000 / 1.000 for all dtypes |
| G | GEMM | 60/60 | 1.000 / 1.000 / 1.000 for all dtypes |

Masked-token observations:

| family | controlled G n=20 mean masked token rate |
| --- | --- |
| ReLU | 0.999960 for all dtypes |
| Softmax | 0.999965 for all dtypes |
| GEMM | 0.999973 for all dtypes |

Baseline masked-token rate is `None` by design. The high G masking rates are consistent with a tight family-specific grammar and should be interpreted as a constraint-strength diagnostic, not as a correctness or quality metric.

## D. Failure Analysis Timeline

1. Initial baseline: the full baseline n=20 run produced 0/180 compile successes. All rows failed as `SignatureError`, dominated by non-canonical source shapes, markdown fences, missing launchers, and invalid generated Python/Triton surfaces.
2. Markdown fence baseline issue: unconstrained generations frequently included fenced code blocks or duplicate fenced snippets. These failed before compile because the source was not a valid canonical Python module.
3. Canonical surface mismatch: the experiment needed a single function-launcher surface rather than a mixed KernelBench `Model` class surface. `.contracts/cluster1_generated_surface.md` now locks the ReLU, Softmax, and GEMM launcher signatures, import order, no-markdown rule, and bracket launch syntax.
4. Launcher/signature mismatch: the validator now checks `inspect.signature()` equality before any dummy launch. Missing or wrong public launchers are recorded as `SignatureError`, including the GEMM identity split where `KernelSpec.name == "gemm"` but the public launcher must be `matmul`.
5. Grammar truncation / `UnexpectedEOF`: earlier constrained generations could terminate as partial modules. Grammar and generation hardening stabilized complete-module emission for the scoped family grammar.
6. Semantic escape hatches: grammar acceptance alone was not enough; accepted source could still use semantically invalid Triton constructs. The grammar was tightened around family-specific canonical patterns.
7. ReLU `tl.max` issue: ReLU initially exposed a semantic escape where reduction-style max syntax could be emitted for pointwise ReLU. ReLU grammar and fixtures were tightened, producing 60/60 in the controlled G run.
8. Historical repaired comparison: before the final Softmax/GEMM hardening, the controlled G n=20 result was 159/180: ReLU 60/60, Softmax 40/60, and GEMM 59/60.
9. Final Softmax/GEMM hardening: latest scoped grammar tightened reduction and matmul families, followed by an L4 post-hardening G n=5 smoke at 45/45 and the final controlled G n=20 run at 180/180.

## Experiment Chronology

| phase | outcome |
| --- | --- |
| Initial baseline | 0/180 compile successes; all `SignatureError` |
| Recovery/resume hardening | Modal run metadata, output validation, resume checks, and infrastructure failure accounting stabilized |
| Canonical surface repair | generated surface contract aligned prompt, grammar, offline validator, and compile validator |
| ReLU semantic hardening | ReLU reached 60/60 compile acceptance under G |
| Historical repaired comparison | baseline 0/180 versus G 159/180 under the repaired prompt/surface and compile-only metric before final Softmax/GEMM hardening |
| Final Softmax/GEMM hardening | latest scoped grammar tightened reduction and matmul families |
| Final controlled L4 comparison | baseline 0/180 versus G 180/180 under the final hardened grammar and compile-only metric |

## E. Methodological Caveats

- Cluster 1 reports compile acceptance only.
- There are no numerical correctness claims.
- There are no performance, timing, speedup, or profiler claims.
- Grammar v1 is scoped to three kernel families: ReLU, Softmax, and GEMM.
- Grammar v1 is not a universal Triton grammar.
- Baseline failures remain `SignatureError` under unconstrained generation.
- The historical 159/180 result is retained only as a pre-final-hardening checkpoint, not the final Cluster 1 headline.

## F. Research Interpretation

Grammar constraints substantially improved compile acceptance in the controlled Cluster 1 setting: 0/180 baseline versus 180/180 G. The improvement is strongest evidence that constrained decoding repaired structural validity for the scoped direct-Triton generation surface.

The historical 159/180 G run showed that syntactic and surface constraints were not enough by themselves. Semantic validity required iterative grammar tightening, especially for reduction and matmul patterns. The final hardened grammar closed those compile-acceptance gaps for the scoped ReLU, Softmax, and GEMM families.

The infrastructure and evaluation stack are operational: JSONL schemas validate, metadata sidecars record completed runs with zero infrastructure failures for inspected run sidecars, the grammar validator reports 10 accept cases and 86 reject cases with no errors, and the analyzer produces compile-only summaries without Cluster 2/3 leakage.

## G. Future Work

- Cluster 2: correctness checks and compiler-feedback loops.
- Cluster 3: RL and performance-oriented evaluation.
- Broader KernelBench generalization beyond the three locked Cluster 1 families.
- Future comparative mechanisms using DSL-mediated approaches such as LEGO and µCUTLASS.

## Final Readiness

Readiness classification: `CLUSTER1_FROZEN`.

Recommended next step: Begin Cluster 2 design from the frozen Cluster 1 artifacts.
