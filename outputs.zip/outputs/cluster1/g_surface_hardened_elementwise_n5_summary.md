# Cluster 1 Compile-Only Summary

## Run Shape

row_count: 15
actual_cells: 3
expected_row_count: 15
expected_conditions: ['G']
actual_conditions: ['G']
expected_kernel_classes: ['elementwise']
actual_kernel_classes: ['elementwise']
expected_dtypes: ['fp32', 'fp16', 'bf16']
actual_dtypes: ['bf16', 'fp16', 'fp32']
missing_cells: 0
unexpected_cells: 0
duplicate_identities: 0

## Compile Metrics

compile_success_scope: all_dtype_strict

| condition | kernel_class | grammar_active | dtype | n | compile_success_scope | compile_successes | compile_failures | compile@1 | prompt_dtype_compile_successes | prompt_dtype_compile_failures | prompt_dtype_compile_success_rate | pass@1 | pass@5 | pass@10 | unique_solution_rate |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| G | elementwise | True | bf16 | 5 | all_dtype_strict | 3 | 2 | 0.600000 | 3 | 2 | 0.600000 | 0.600000 | 1.000000 | NA | 0.400000 |
| G | elementwise | True | fp16 | 5 | all_dtype_strict | 3 | 2 | 0.600000 | 3 | 2 | 0.600000 | 0.600000 | 1.000000 | NA | 0.400000 |
| G | elementwise | True | fp32 | 5 | all_dtype_strict | 3 | 2 | 0.600000 | 3 | 2 | 0.600000 | 0.600000 | 1.000000 | NA | 0.400000 |

## Masked Token Rate

| condition | kernel_class | dtype | n | mean | min | max |
| --- | --- | --- | --- | --- | --- | --- |
| G | elementwise | bf16 | 5 | 0.939809 | 0.936908 | 0.943830 |
| G | elementwise | fp16 | 5 | 0.939809 | 0.936908 | 0.943830 |
| G | elementwise | fp32 | 5 | 0.939875 | 0.937239 | 0.943830 |

## Compile Error Types

| condition | kernel_class | dtype | compile_error_type | count |
| --- | --- | --- | --- | --- |
| G | elementwise | bf16 | CompilationError | 2 |
| G | elementwise | bf16 | None | 3 |
| G | elementwise | fp16 | CompilationError | 2 |
| G | elementwise | fp16 | None | 3 |
| G | elementwise | fp32 | CompilationError | 2 |
| G | elementwise | fp32 | None | 3 |

## Null-Hypothesis Report

- `kernel_class=elementwise`, `dtype=bf16`: comparison requires both baseline and G rows; observed 1 condition group(s).
- `kernel_class=elementwise`, `dtype=fp16`: comparison requires both baseline and G rows; observed 1 condition group(s).
- `kernel_class=elementwise`, `dtype=fp32`: comparison requires both baseline and G rows; observed 1 condition group(s).
