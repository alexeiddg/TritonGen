# Cluster 1 Compile-Only Summary

## Run Shape

row_count: 180
actual_cells: 9
expected_row_count: 180
expected_conditions: ['baseline']
actual_conditions: ['baseline']
expected_kernel_classes: ['elementwise', 'reduction', 'matmul']
actual_kernel_classes: ['elementwise', 'matmul', 'reduction']
expected_dtypes: ['fp32', 'fp16', 'bf16']
actual_dtypes: ['bf16', 'fp16', 'fp32']
missing_cells: 0
unexpected_cells: 0
duplicate_identities: 0

## Compile Metrics

compile_success_scope: all_dtype_strict

| condition | kernel_class | grammar_active | dtype | n | compile_success_scope | compile_successes | compile_failures | compile@1 | prompt_dtype_compile_successes | prompt_dtype_compile_failures | prompt_dtype_compile_success_rate | pass@1 | pass@5 | pass@10 | unique_solution_rate |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| baseline | elementwise | False | bf16 | 20 | all_dtype_strict | 0 | 20 | 0.000000 | 0 | 20 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 0.950000 |
| baseline | elementwise | False | fp16 | 20 | all_dtype_strict | 0 | 20 | 0.000000 | 0 | 20 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 0.850000 |
| baseline | elementwise | False | fp32 | 20 | all_dtype_strict | 0 | 20 | 0.000000 | 0 | 20 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 0.750000 |
| baseline | matmul | False | bf16 | 20 | all_dtype_strict | 0 | 20 | 0.000000 | 0 | 20 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 1.000000 |
| baseline | matmul | False | fp16 | 20 | all_dtype_strict | 0 | 20 | 0.000000 | 0 | 20 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 1.000000 |
| baseline | matmul | False | fp32 | 20 | all_dtype_strict | 0 | 20 | 0.000000 | 0 | 20 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 1.000000 |
| baseline | reduction | False | bf16 | 20 | all_dtype_strict | 0 | 20 | 0.000000 | 0 | 20 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 0.850000 |
| baseline | reduction | False | fp16 | 20 | all_dtype_strict | 0 | 20 | 0.000000 | 0 | 20 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 0.750000 |
| baseline | reduction | False | fp32 | 20 | all_dtype_strict | 0 | 20 | 0.000000 | 0 | 20 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 0.700000 |

## Masked Token Rate

No G rows found.

## Compile Error Types

| condition | kernel_class | dtype | compile_error_type | count |
| --- | --- | --- | --- | --- |
| baseline | elementwise | bf16 | SignatureError | 20 |
| baseline | elementwise | fp16 | SignatureError | 20 |
| baseline | elementwise | fp32 | SignatureError | 20 |
| baseline | matmul | bf16 | SignatureError | 20 |
| baseline | matmul | fp16 | SignatureError | 20 |
| baseline | matmul | fp32 | SignatureError | 20 |
| baseline | reduction | bf16 | SignatureError | 20 |
| baseline | reduction | fp16 | SignatureError | 20 |
| baseline | reduction | fp32 | SignatureError | 20 |

## Null-Hypothesis Report

- `kernel_class=elementwise`, `dtype=bf16`: comparison requires both baseline and G rows; observed 1 condition group(s).
- `kernel_class=elementwise`, `dtype=fp16`: comparison requires both baseline and G rows; observed 1 condition group(s).
- `kernel_class=elementwise`, `dtype=fp32`: comparison requires both baseline and G rows; observed 1 condition group(s).
- `kernel_class=matmul`, `dtype=bf16`: comparison requires both baseline and G rows; observed 1 condition group(s).
- `kernel_class=matmul`, `dtype=fp16`: comparison requires both baseline and G rows; observed 1 condition group(s).
- `kernel_class=matmul`, `dtype=fp32`: comparison requires both baseline and G rows; observed 1 condition group(s).
- `kernel_class=reduction`, `dtype=bf16`: comparison requires both baseline and G rows; observed 1 condition group(s).
- `kernel_class=reduction`, `dtype=fp16`: comparison requires both baseline and G rows; observed 1 condition group(s).
- `kernel_class=reduction`, `dtype=fp32`: comparison requires both baseline and G rows; observed 1 condition group(s).
