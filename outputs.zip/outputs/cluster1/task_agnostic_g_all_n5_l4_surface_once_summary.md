# Cluster 1 Compile-Only Summary

## Run Shape

row_count: 45
actual_cells: 9
expected_row_count: 45
expected_conditions: ['G']
actual_conditions: ['G']
expected_grammar_variants: ['task_agnostic']
actual_grammar_variants: ['task_agnostic']
expected_kernel_classes: ['elementwise', 'reduction', 'matmul']
actual_kernel_classes: ['elementwise', 'matmul', 'reduction']
expected_dtypes: ['fp32', 'fp16', 'bf16']
actual_dtypes: ['bf16', 'fp16', 'fp32']
missing_cells: 0
unexpected_cells: 0
duplicate_identities: 0

## Compile Metrics

compile_success_scope: all_dtype_strict

| condition | grammar_variant | kernel_class | dtype | n | compile_success_scope | compile_successes | compile_failures | compile@1 | prompt_dtype_compile_successes | prompt_dtype_compile_failures | prompt_dtype_compile_success_rate | pass@1 | pass@5 | pass@10 | unique_solution_rate |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| G | task_agnostic | elementwise | bf16 | 5 | all_dtype_strict | 0 | 5 | 0.000000 | 3 | 2 | 0.600000 | 0.000000 | 0.000000 | NA | 0.800000 |
| G | task_agnostic | elementwise | fp16 | 5 | all_dtype_strict | 0 | 5 | 0.000000 | 1 | 4 | 0.200000 | 0.000000 | 0.000000 | NA | 1.000000 |
| G | task_agnostic | elementwise | fp32 | 5 | all_dtype_strict | 1 | 4 | 0.200000 | 1 | 4 | 0.200000 | 0.200000 | 1.000000 | NA | 1.000000 |
| G | task_agnostic | matmul | bf16 | 5 | all_dtype_strict | 0 | 5 | 0.000000 | 0 | 5 | 0.000000 | 0.000000 | 0.000000 | NA | 0.800000 |
| G | task_agnostic | matmul | fp16 | 5 | all_dtype_strict | 0 | 5 | 0.000000 | 0 | 5 | 0.000000 | 0.000000 | 0.000000 | NA | 1.000000 |
| G | task_agnostic | matmul | fp32 | 5 | all_dtype_strict | 0 | 5 | 0.000000 | 0 | 5 | 0.000000 | 0.000000 | 0.000000 | NA | 1.000000 |
| G | task_agnostic | reduction | bf16 | 5 | all_dtype_strict | 0 | 5 | 0.000000 | 0 | 5 | 0.000000 | 0.000000 | 0.000000 | NA | 1.000000 |
| G | task_agnostic | reduction | fp16 | 5 | all_dtype_strict | 0 | 5 | 0.000000 | 0 | 5 | 0.000000 | 0.000000 | 0.000000 | NA | 1.000000 |
| G | task_agnostic | reduction | fp32 | 5 | all_dtype_strict | 0 | 5 | 0.000000 | 0 | 5 | 0.000000 | 0.000000 | 0.000000 | NA | 1.000000 |

## Masked Token Rate

| condition | grammar_variant | kernel_class | dtype | n | mean | min | max |
| --- | --- | --- | --- | --- | --- | --- | --- |
| G | task_agnostic | elementwise | bf16 | 5 | 0.803426 | 0.801764 | 0.805290 |
| G | task_agnostic | elementwise | fp16 | 5 | 0.804562 | 0.800962 | 0.806477 |
| G | task_agnostic | elementwise | fp32 | 5 | 0.835856 | 0.799505 | 0.851857 |
| G | task_agnostic | matmul | bf16 | 5 | 0.743591 | 0.732040 | 0.755322 |
| G | task_agnostic | matmul | fp16 | 5 | 0.754758 | 0.729088 | 0.787026 |
| G | task_agnostic | matmul | fp32 | 5 | 0.779284 | 0.755087 | 0.816089 |
| G | task_agnostic | reduction | bf16 | 5 | 0.777226 | 0.750693 | 0.807433 |
| G | task_agnostic | reduction | fp16 | 5 | 0.768326 | 0.726688 | 0.801122 |
| G | task_agnostic | reduction | fp32 | 5 | 0.770820 | 0.759786 | 0.786690 |

## Compile Error Types

| condition | grammar_variant | kernel_class | dtype | compile_error_type | count |
| --- | --- | --- | --- | --- | --- |
| G | task_agnostic | elementwise | bf16 | RuntimeError | 5 |
| G | task_agnostic | elementwise | fp16 | RuntimeError | 5 |
| G | task_agnostic | elementwise | fp32 | CompilationError | 1 |
| G | task_agnostic | elementwise | fp32 | None | 1 |
| G | task_agnostic | elementwise | fp32 | RuntimeError | 3 |
| G | task_agnostic | matmul | bf16 | RuntimeError | 4 |
| G | task_agnostic | matmul | bf16 | SignatureError | 1 |
| G | task_agnostic | matmul | fp16 | RuntimeError | 5 |
| G | task_agnostic | matmul | fp32 | RuntimeError | 5 |
| G | task_agnostic | reduction | bf16 | RuntimeError | 5 |
| G | task_agnostic | reduction | fp16 | RuntimeError | 5 |
| G | task_agnostic | reduction | fp32 | RuntimeError | 5 |

## Null-Hypothesis Report

- `kernel_class=elementwise`, `dtype=bf16`: comparison requires both baseline and G rows; observed 1 condition group(s).
- `kernel_class=elementwise`, `dtype=fp16`: comparison requires both baseline and G rows; observed 1 condition group(s).
- `kernel_class=elementwise`, `dtype=fp32`: comparison requires both baseline and G rows; observed 1 condition group(s).
- `kernel_class=matmul`, `dtype=bf16`: comparison requires both baseline and G rows; observed 1 condition group(s).
- `kernel_class=matmul`, `dtype=fp16`: comparison requires both baseline and G rows; observed 1 condition group(s).
- `kernel_class=matmul`, `dtype=fp32`: comparison requires both baseline and G rows; observed 1 condition group(s).
- `kernel_class=reduction`, `dtype=bf16`: comparison requires both baseline and G rows; observed 1 condition group(s).
- `kernel_class=reduction`, `dtype=fp16`: comparison requires both baseline and G rows; observed 1 condition group(s).
- `kernel_class=reduction`, `dtype=fp32`: comparison requires both baseline and G rows; observed 1 condition group(s).
