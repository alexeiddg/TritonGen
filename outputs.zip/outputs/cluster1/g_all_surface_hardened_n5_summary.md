# Cluster 1 Compile-Only Summary

## Run Shape

row_count: 45
actual_cells: 9
expected_row_count: 45
expected_conditions: ['G']
actual_conditions: ['G']
expected_kernel_classes: ['elementwise', 'reduction', 'matmul']
actual_kernel_classes: ['elementwise', 'matmul', 'reduction']
expected_dtypes: ['fp32', 'fp16', 'bf16']
actual_dtypes: ['bf16', 'fp16', 'fp32']
missing_cells: 0
unexpected_cells: 0
duplicate_identities: 0

## Compile Metrics

compile_success_scope: all_dtype_strict

| condition | kernel_class | grammar_active | dtype | n | compile_success_scope | compile_successes | compile_failures | compile@1 | prompt_dtype_compile_successes | prompt_dtype_compile_failures | prompt_dtype_compile_success_rate | pass@1 | pass@5 | pass@10 | unique_solution_rate |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| G | elementwise | True | bf16 | 5 | all_dtype_strict | 5 | 0 | 1.000000 | 5 | 0 | 1.000000 | 1.000000 | 1.000000 | NA | 0.200000 |
| G | elementwise | True | fp16 | 5 | all_dtype_strict | 5 | 0 | 1.000000 | 5 | 0 | 1.000000 | 1.000000 | 1.000000 | NA | 0.200000 |
| G | elementwise | True | fp32 | 5 | all_dtype_strict | 5 | 0 | 1.000000 | 5 | 0 | 1.000000 | 1.000000 | 1.000000 | NA | 0.200000 |
| G | matmul | True | bf16 | 5 | all_dtype_strict | 5 | 0 | 1.000000 | 5 | 0 | 1.000000 | 1.000000 | 1.000000 | NA | 0.200000 |
| G | matmul | True | fp16 | 5 | all_dtype_strict | 5 | 0 | 1.000000 | 5 | 0 | 1.000000 | 1.000000 | 1.000000 | NA | 0.200000 |
| G | matmul | True | fp32 | 5 | all_dtype_strict | 5 | 0 | 1.000000 | 5 | 0 | 1.000000 | 1.000000 | 1.000000 | NA | 0.200000 |
| G | reduction | True | bf16 | 5 | all_dtype_strict | 5 | 0 | 1.000000 | 5 | 0 | 1.000000 | 1.000000 | 1.000000 | NA | 0.200000 |
| G | reduction | True | fp16 | 5 | all_dtype_strict | 5 | 0 | 1.000000 | 5 | 0 | 1.000000 | 1.000000 | 1.000000 | NA | 0.200000 |
| G | reduction | True | fp32 | 5 | all_dtype_strict | 5 | 0 | 1.000000 | 5 | 0 | 1.000000 | 1.000000 | 1.000000 | NA | 0.200000 |

## Masked Token Rate

| condition | kernel_class | dtype | n | mean | min | max |
| --- | --- | --- | --- | --- | --- | --- |
| G | elementwise | bf16 | 5 | 0.999960 | 0.999960 | 0.999960 |
| G | elementwise | fp16 | 5 | 0.999960 | 0.999960 | 0.999960 |
| G | elementwise | fp32 | 5 | 0.999960 | 0.999960 | 0.999960 |
| G | matmul | bf16 | 5 | 0.977895 | 0.977895 | 0.977895 |
| G | matmul | fp16 | 5 | 0.977895 | 0.977895 | 0.977895 |
| G | matmul | fp32 | 5 | 0.977895 | 0.977895 | 0.977895 |
| G | reduction | bf16 | 5 | 0.975777 | 0.975777 | 0.975777 |
| G | reduction | fp16 | 5 | 0.975777 | 0.975777 | 0.975777 |
| G | reduction | fp32 | 5 | 0.975777 | 0.975777 | 0.975777 |

## Compile Error Types

| condition | kernel_class | dtype | compile_error_type | count |
| --- | --- | --- | --- | --- |
| G | elementwise | bf16 | None | 5 |
| G | elementwise | fp16 | None | 5 |
| G | elementwise | fp32 | None | 5 |
| G | matmul | bf16 | None | 5 |
| G | matmul | fp16 | None | 5 |
| G | matmul | fp32 | None | 5 |
| G | reduction | bf16 | None | 5 |
| G | reduction | fp16 | None | 5 |
| G | reduction | fp32 | None | 5 |

## Null-Hypothesis Report

- `kernel_class=elementwise`, `dtype=bf16`: comparison requires both baseline and G rows; observed 1 condition group(s).
- `kernel_class=elementwise`, `dtype=fp16`: comparison requires both baseline and G rows; observed 1 condition group(s).
- `kernel_class=elementwise`, `dtype=fp32`: comparison requires both baseline and G rows; observed 1 condition group(s).
- `kernel_class=matmul`, `dtype=bf16`: comparison requires both baseline and G rows; observed 1 condition group(s).
- `kernel_class=matmul`, `dtype=fp16`: comparison requires both baseline and G rows; observed 1 condition group(s).
- `kernel_class=matmul`, `dtype=fp32`: comparison requires both baseline and G rows; observed 1 condition group(s).
- `kernel_class=reduction`, `dtype=bf16`: comparison requires both baseline and G rows; observed 1 condition group(s).
- `kernel_class=reduction`, `dtype=fp16`: comparison requires both baseline and G rows; observed 1 condition group(s).
- `kernel_class=reduction`, `dtype=fp32`: comparison requires both baseline and G rows; observed 1 condition group(s).
