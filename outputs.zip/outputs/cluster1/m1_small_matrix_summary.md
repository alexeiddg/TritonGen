# Cluster 1 Compile-Only Summary

## Run Shape

row_count: 36
actual_cells: 18
expected_row_count: 36
expected_conditions: ['baseline', 'G']
actual_conditions: ['G', 'baseline']
expected_kernel_classes: ['elementwise', 'reduction', 'matmul']
actual_kernel_classes: ['elementwise', 'matmul', 'reduction']
expected_dtypes: ['fp32', 'fp16', 'bf16']
actual_dtypes: ['bf16', 'fp16', 'fp32']
missing_cells: 0
unexpected_cells: 0
duplicate_identities: 0

## Compile Metrics

compile_success_scope: all_dtype_strict

| condition | kernel_class | grammar_active | dtype | n | compile_success_scope | compile_successes | compile_failures | compile@1 | prompt_dtype_compile_successes | prompt_dtype_compile_failures | prompt_dtype_compile_success_rate | pass@1 | pass@5 | pass@10 | unique_solution_rate |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| G | elementwise | True | bf16 | 2 | all_dtype_strict | 0 | 2 | 0.000000 | 0 | 2 | 0.000000 | 0.000000 | NA | NA | 1.000000 |
| G | elementwise | True | fp16 | 2 | all_dtype_strict | 0 | 2 | 0.000000 | 0 | 2 | 0.000000 | 0.000000 | NA | NA | 1.000000 |
| G | elementwise | True | fp32 | 2 | all_dtype_strict | 0 | 2 | 0.000000 | 0 | 2 | 0.000000 | 0.000000 | NA | NA | 1.000000 |
| G | matmul | True | bf16 | 2 | all_dtype_strict | 0 | 2 | 0.000000 | 0 | 2 | 0.000000 | 0.000000 | NA | NA | 1.000000 |
| G | matmul | True | fp16 | 2 | all_dtype_strict | 0 | 2 | 0.000000 | 0 | 2 | 0.000000 | 0.000000 | NA | NA | 1.000000 |
| G | matmul | True | fp32 | 2 | all_dtype_strict | 0 | 2 | 0.000000 | 0 | 2 | 0.000000 | 0.000000 | NA | NA | 1.000000 |
| G | reduction | True | bf16 | 2 | all_dtype_strict | 0 | 2 | 0.000000 | 0 | 2 | 0.000000 | 0.000000 | NA | NA | 1.000000 |
| G | reduction | True | fp16 | 2 | all_dtype_strict | 0 | 2 | 0.000000 | 0 | 2 | 0.000000 | 0.000000 | NA | NA | 1.000000 |
| G | reduction | True | fp32 | 2 | all_dtype_strict | 0 | 2 | 0.000000 | 0 | 2 | 0.000000 | 0.000000 | NA | NA | 1.000000 |
| baseline | elementwise | False | bf16 | 2 | all_dtype_strict | 0 | 2 | 0.000000 | 0 | 2 | 0.000000 | 0.000000 | NA | NA | 1.000000 |
| baseline | elementwise | False | fp16 | 2 | all_dtype_strict | 0 | 2 | 0.000000 | 0 | 2 | 0.000000 | 0.000000 | NA | NA | 1.000000 |
| baseline | elementwise | False | fp32 | 2 | all_dtype_strict | 0 | 2 | 0.000000 | 0 | 2 | 0.000000 | 0.000000 | NA | NA | 1.000000 |
| baseline | matmul | False | bf16 | 2 | all_dtype_strict | 0 | 2 | 0.000000 | 0 | 2 | 0.000000 | 0.000000 | NA | NA | 1.000000 |
| baseline | matmul | False | fp16 | 2 | all_dtype_strict | 0 | 2 | 0.000000 | 0 | 2 | 0.000000 | 0.000000 | NA | NA | 1.000000 |
| baseline | matmul | False | fp32 | 2 | all_dtype_strict | 0 | 2 | 0.000000 | 0 | 2 | 0.000000 | 0.000000 | NA | NA | 1.000000 |
| baseline | reduction | False | bf16 | 2 | all_dtype_strict | 0 | 2 | 0.000000 | 0 | 2 | 0.000000 | 0.000000 | NA | NA | 1.000000 |
| baseline | reduction | False | fp16 | 2 | all_dtype_strict | 0 | 2 | 0.000000 | 0 | 2 | 0.000000 | 0.000000 | NA | NA | 1.000000 |
| baseline | reduction | False | fp32 | 2 | all_dtype_strict | 0 | 2 | 0.000000 | 0 | 2 | 0.000000 | 0.000000 | NA | NA | 0.500000 |

## Masked Token Rate

| condition | kernel_class | dtype | n | mean | min | max |
| --- | --- | --- | --- | --- | --- | --- |
| G | elementwise | bf16 | 2 | 0.777845 | 0.777830 | 0.777860 |
| G | elementwise | fp16 | 2 | 0.814531 | 0.774700 | 0.854362 |
| G | elementwise | fp32 | 2 | 0.807303 | 0.774700 | 0.839906 |
| G | matmul | bf16 | 2 | 0.798533 | 0.791952 | 0.805114 |
| G | matmul | fp16 | 2 | 0.826581 | 0.805114 | 0.848048 |
| G | matmul | fp32 | 2 | 0.798533 | 0.791952 | 0.805114 |
| G | reduction | bf16 | 2 | 0.834754 | 0.825127 | 0.844381 |
| G | reduction | fp16 | 2 | 0.816094 | 0.802899 | 0.829288 |
| G | reduction | fp32 | 2 | 0.801915 | 0.777638 | 0.826192 |

## Compile Error Types

| condition | kernel_class | dtype | compile_error_type | count |
| --- | --- | --- | --- | --- |
| G | elementwise | bf16 | SignatureError | 2 |
| G | elementwise | fp16 | SignatureError | 2 |
| G | elementwise | fp32 | SignatureError | 2 |
| G | matmul | bf16 | SignatureError | 2 |
| G | matmul | fp16 | SignatureError | 2 |
| G | matmul | fp32 | SignatureError | 2 |
| G | reduction | bf16 | SignatureError | 2 |
| G | reduction | fp16 | SignatureError | 2 |
| G | reduction | fp32 | SignatureError | 2 |
| baseline | elementwise | bf16 | SignatureError | 2 |
| baseline | elementwise | fp16 | SignatureError | 2 |
| baseline | elementwise | fp32 | SignatureError | 2 |
| baseline | matmul | bf16 | SignatureError | 2 |
| baseline | matmul | fp16 | SignatureError | 2 |
| baseline | matmul | fp32 | SignatureError | 2 |
| baseline | reduction | bf16 | SignatureError | 2 |
| baseline | reduction | fp16 | SignatureError | 2 |
| baseline | reduction | fp32 | SignatureError | 2 |

## Null-Hypothesis Report

- Anomaly for `kernel_class=elementwise`, `dtype=bf16`: OFF failures=2, ON failures=2. DoD #7 requires documentation.
- Anomaly for `kernel_class=elementwise`, `dtype=fp16`: OFF failures=2, ON failures=2. DoD #7 requires documentation.
- Anomaly for `kernel_class=elementwise`, `dtype=fp32`: OFF failures=2, ON failures=2. DoD #7 requires documentation.
- Anomaly for `kernel_class=matmul`, `dtype=bf16`: OFF failures=2, ON failures=2. DoD #7 requires documentation.
- Anomaly for `kernel_class=matmul`, `dtype=fp16`: OFF failures=2, ON failures=2. DoD #7 requires documentation.
- Anomaly for `kernel_class=matmul`, `dtype=fp32`: OFF failures=2, ON failures=2. DoD #7 requires documentation.
- Anomaly for `kernel_class=reduction`, `dtype=bf16`: OFF failures=2, ON failures=2. DoD #7 requires documentation.
- Anomaly for `kernel_class=reduction`, `dtype=fp16`: OFF failures=2, ON failures=2. DoD #7 requires documentation.
- Anomaly for `kernel_class=reduction`, `dtype=fp32`: OFF failures=2, ON failures=2. DoD #7 requires documentation.
