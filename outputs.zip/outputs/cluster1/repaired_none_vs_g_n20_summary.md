# Cluster 1 Compile-Only Summary

## Run Shape

row_count: 360
actual_cells: 18
expected_row_count: 360
expected_conditions: ['baseline', 'G']
actual_conditions: ['G', 'baseline']
expected_kernel_classes: ['elementwise', 'reduction', 'matmul']
actual_kernel_classes: ['elementwise', 'matmul', 'reduction']
expected_dtypes: ['fp32', 'fp16', 'bf16']
actual_dtypes: ['bf16', 'fp16', 'fp32']
missing_cells: 0
unexpected_cells: 0
duplicate_identities: 0

## Compile Metrics

compile_success_scope: all_dtype_strict

| condition | kernel_class | grammar_active | dtype | n | compile_success_scope | compile_successes | compile_failures | compile@1 | prompt_dtype_compile_successes | prompt_dtype_compile_failures | prompt_dtype_compile_success_rate | pass@1 | pass@5 | pass@10 | unique_solution_rate |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| G | elementwise | True | bf16 | 20 | all_dtype_strict | 20 | 0 | 1.000000 | 20 | 0 | 1.000000 | 1.000000 | 1.000000 | 1.000000 | 0.050000 |
| G | elementwise | True | fp16 | 20 | all_dtype_strict | 20 | 0 | 1.000000 | 20 | 0 | 1.000000 | 1.000000 | 1.000000 | 1.000000 | 0.050000 |
| G | elementwise | True | fp32 | 20 | all_dtype_strict | 20 | 0 | 1.000000 | 20 | 0 | 1.000000 | 1.000000 | 1.000000 | 1.000000 | 0.050000 |
| G | matmul | True | bf16 | 20 | all_dtype_strict | 20 | 0 | 1.000000 | 20 | 0 | 1.000000 | 1.000000 | 1.000000 | 1.000000 | 0.050000 |
| G | matmul | True | fp16 | 20 | all_dtype_strict | 20 | 0 | 1.000000 | 20 | 0 | 1.000000 | 1.000000 | 1.000000 | 1.000000 | 0.100000 |
| G | matmul | True | fp32 | 20 | all_dtype_strict | 19 | 1 | 0.950000 | 19 | 1 | 0.950000 | 0.950000 | 1.000000 | 1.000000 | 0.150000 |
| G | reduction | True | bf16 | 20 | all_dtype_strict | 11 | 9 | 0.550000 | 11 | 9 | 0.550000 | 0.550000 | 0.991873 | 1.000000 | 0.500000 |
| G | reduction | True | fp16 | 20 | all_dtype_strict | 14 | 6 | 0.700000 | 14 | 6 | 0.700000 | 0.700000 | 0.999613 | 1.000000 | 0.400000 |
| G | reduction | True | fp32 | 20 | all_dtype_strict | 15 | 5 | 0.750000 | 15 | 5 | 0.750000 | 0.750000 | 0.999936 | 1.000000 | 0.450000 |
| baseline | elementwise | False | bf16 | 20 | all_dtype_strict | 0 | 20 | 0.000000 | 0 | 20 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 0.800000 |
| baseline | elementwise | False | fp16 | 20 | all_dtype_strict | 0 | 20 | 0.000000 | 0 | 20 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 0.800000 |
| baseline | elementwise | False | fp32 | 20 | all_dtype_strict | 0 | 20 | 0.000000 | 0 | 20 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 0.550000 |
| baseline | matmul | False | bf16 | 20 | all_dtype_strict | 0 | 20 | 0.000000 | 0 | 20 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 1.000000 |
| baseline | matmul | False | fp16 | 20 | all_dtype_strict | 0 | 20 | 0.000000 | 0 | 20 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 1.000000 |
| baseline | matmul | False | fp32 | 20 | all_dtype_strict | 0 | 20 | 0.000000 | 0 | 20 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 1.000000 |
| baseline | reduction | False | bf16 | 20 | all_dtype_strict | 0 | 20 | 0.000000 | 0 | 20 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 0.650000 |
| baseline | reduction | False | fp16 | 20 | all_dtype_strict | 0 | 20 | 0.000000 | 0 | 20 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 0.650000 |
| baseline | reduction | False | fp32 | 20 | all_dtype_strict | 0 | 20 | 0.000000 | 0 | 20 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 1.000000 |

## Masked Token Rate

| condition | kernel_class | dtype | n | mean | min | max |
| --- | --- | --- | --- | --- | --- | --- |
| G | elementwise | bf16 | 20 | 0.999960 | 0.999960 | 0.999960 |
| G | elementwise | fp16 | 20 | 0.999960 | 0.999960 | 0.999960 |
| G | elementwise | fp32 | 20 | 0.999960 | 0.999960 | 0.999960 |
| G | matmul | bf16 | 20 | 0.977895 | 0.977895 | 0.977895 |
| G | matmul | fp16 | 20 | 0.977899 | 0.977895 | 0.977985 |
| G | matmul | fp32 | 20 | 0.977939 | 0.977895 | 0.978783 |
| G | reduction | bf16 | 20 | 0.949388 | 0.910065 | 0.975931 |
| G | reduction | fp16 | 20 | 0.958113 | 0.908068 | 0.975931 |
| G | reduction | fp32 | 20 | 0.959382 | 0.898310 | 0.975931 |

## Compile Error Types

| condition | kernel_class | dtype | compile_error_type | count |
| --- | --- | --- | --- | --- |
| G | elementwise | bf16 | None | 20 |
| G | elementwise | fp16 | None | 20 |
| G | elementwise | fp32 | None | 20 |
| G | matmul | bf16 | None | 20 |
| G | matmul | fp16 | None | 20 |
| G | matmul | fp32 | CompilationError | 1 |
| G | matmul | fp32 | None | 19 |
| G | reduction | bf16 | CompilationError | 5 |
| G | reduction | bf16 | None | 11 |
| G | reduction | bf16 | SignatureError | 4 |
| G | reduction | fp16 | CompilationError | 4 |
| G | reduction | fp16 | None | 14 |
| G | reduction | fp16 | SignatureError | 2 |
| G | reduction | fp32 | CompilationError | 2 |
| G | reduction | fp32 | None | 15 |
| G | reduction | fp32 | SignatureError | 3 |
| baseline | elementwise | bf16 | SignatureError | 20 |
| baseline | elementwise | fp16 | SignatureError | 20 |
| baseline | elementwise | fp32 | SignatureError | 20 |
| baseline | matmul | bf16 | SignatureError | 20 |
| baseline | matmul | fp16 | SignatureError | 20 |
| baseline | matmul | fp32 | SignatureError | 20 |
| baseline | reduction | bf16 | SignatureError | 20 |
| baseline | reduction | fp16 | SignatureError | 20 |
| baseline | reduction | fp32 | SignatureError | 20 |

## Null-Hypothesis Report

- `kernel_class=elementwise`, `dtype=bf16`: grammar ON eliminated 20 compile failure(s) (20 OFF failures vs 0 ON failures).
- `kernel_class=elementwise`, `dtype=fp16`: grammar ON eliminated 20 compile failure(s) (20 OFF failures vs 0 ON failures).
- `kernel_class=elementwise`, `dtype=fp32`: grammar ON eliminated 20 compile failure(s) (20 OFF failures vs 0 ON failures).
- `kernel_class=matmul`, `dtype=bf16`: grammar ON eliminated 20 compile failure(s) (20 OFF failures vs 0 ON failures).
- `kernel_class=matmul`, `dtype=fp16`: grammar ON eliminated 20 compile failure(s) (20 OFF failures vs 0 ON failures).
- `kernel_class=matmul`, `dtype=fp32`: grammar ON eliminated 19 compile failure(s) (20 OFF failures vs 1 ON failures).
- `kernel_class=reduction`, `dtype=bf16`: grammar ON eliminated 11 compile failure(s) (20 OFF failures vs 9 ON failures).
- `kernel_class=reduction`, `dtype=fp16`: grammar ON eliminated 14 compile failure(s) (20 OFF failures vs 6 ON failures).
- `kernel_class=reduction`, `dtype=fp32`: grammar ON eliminated 15 compile failure(s) (20 OFF failures vs 5 ON failures).
