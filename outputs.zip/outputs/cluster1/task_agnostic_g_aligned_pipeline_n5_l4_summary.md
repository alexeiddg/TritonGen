# Cluster 1 Compile-Only Summary

## Run Shape

row_count: 45
actual_cells: 9
expected_row_count: 45
expected_conditions: ['G']
actual_conditions: ['G']
expected_grammar_variants: ['task_agnostic (task-agnostic G primary)']
actual_grammar_variants: ['task_agnostic (task-agnostic G primary)']
expected_kernel_classes: ['elementwise', 'reduction', 'matmul']
actual_kernel_classes: ['elementwise', 'matmul', 'reduction']
expected_dtypes: ['fp32', 'fp16', 'bf16']
actual_dtypes: ['bf16', 'fp16', 'fp32']
missing_cells: 0
unexpected_cells: 0
duplicate_identities: 0

## Compile Metrics

compile_success_scope: all_dtype_strict

| condition | grammar_variant | kernel_class | dtype | n | grammar_valid_count | grammar_valid_rate | gbnf_parse_valid_rate | semantic_valid_rate | compile_success_scope | compile_successes | compile_failures | compile@1 | prompt_dtype_compile_successes | prompt_dtype_compile_failures | prompt_dtype_compile_success_rate | pass@1 | pass@5 | pass@10 | unique_solution_rate |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| G | task-agnostic G | elementwise | bf16 | 5 | 5 | 1.000000 | 1.000000 | 1.000000 | all_dtype_strict | 0 | 5 | 0.000000 | 4 | 1 | 0.800000 | 0.000000 | 0.000000 | NA | 0.600000 |
| G | task-agnostic G | elementwise | fp16 | 5 | 4 | 0.800000 | 1.000000 | 0.800000 | all_dtype_strict | 0 | 5 | 0.000000 | 1 | 4 | 0.200000 | 0.000000 | 0.000000 | NA | 1.000000 |
| G | task-agnostic G | elementwise | fp32 | 5 | 3 | 0.600000 | 1.000000 | 0.600000 | all_dtype_strict | 1 | 4 | 0.200000 | 1 | 4 | 0.200000 | 0.200000 | 1.000000 | NA | 1.000000 |
| G | task-agnostic G | matmul | bf16 | 5 | 0 | 0.000000 | 0.400000 | 0.000000 | all_dtype_strict | 0 | 5 | 0.000000 | 0 | 5 | 0.000000 | 0.000000 | 0.000000 | NA | 0.800000 |
| G | task-agnostic G | matmul | fp16 | 5 | 0 | 0.000000 | 0.800000 | 0.000000 | all_dtype_strict | 0 | 5 | 0.000000 | 0 | 5 | 0.000000 | 0.000000 | 0.000000 | NA | 1.000000 |
| G | task-agnostic G | matmul | fp32 | 5 | 0 | 0.000000 | 0.800000 | 0.000000 | all_dtype_strict | 0 | 5 | 0.000000 | 0 | 5 | 0.000000 | 0.000000 | 0.000000 | NA | 1.000000 |
| G | task-agnostic G | reduction | bf16 | 5 | 0 | 0.000000 | 0.200000 | 0.000000 | all_dtype_strict | 0 | 5 | 0.000000 | 0 | 5 | 0.000000 | 0.000000 | 0.000000 | NA | 1.000000 |
| G | task-agnostic G | reduction | fp16 | 5 | 0 | 0.000000 | 0.000000 | 0.000000 | all_dtype_strict | 0 | 5 | 0.000000 | 0 | 5 | 0.000000 | 0.000000 | 0.000000 | NA | 1.000000 |
| G | task-agnostic G | reduction | fp32 | 5 | 0 | 0.000000 | 0.200000 | 0.000000 | all_dtype_strict | 0 | 5 | 0.000000 | 0 | 5 | 0.000000 | 0.000000 | 0.000000 | NA | 1.000000 |

## Masked Token Rate

| condition | grammar_variant | kernel_class | dtype | n | mean | min | max |
| --- | --- | --- | --- | --- | --- | --- | --- |
| G | task-agnostic G | elementwise | bf16 | 5 | 0.803707 | 0.800085 | 0.805290 |
| G | task-agnostic G | elementwise | fp16 | 5 | 0.804199 | 0.800962 | 0.806477 |
| G | task-agnostic G | elementwise | fp32 | 5 | 0.843281 | 0.836081 | 0.851857 |
| G | task-agnostic G | matmul | bf16 | 5 | 0.745505 | 0.740859 | 0.755322 |
| G | task-agnostic G | matmul | fp16 | 5 | 0.756351 | 0.729088 | 0.811026 |
| G | task-agnostic G | matmul | fp32 | 5 | 0.792945 | 0.746621 | 0.816784 |
| G | task-agnostic G | reduction | bf16 | 5 | 0.767758 | 0.745522 | 0.807433 |
| G | task-agnostic G | reduction | fp16 | 5 | 0.766540 | 0.745901 | 0.788418 |
| G | task-agnostic G | reduction | fp32 | 5 | 0.772464 | 0.747796 | 0.805614 |

## Failure Codes

| condition | grammar_variant | kernel_class | dtype | failure_code | count |
| --- | --- | --- | --- | --- | --- |
| G | task-agnostic G | elementwise | bf16 | F1_RUNTIME | 5 |
| G | task-agnostic G | elementwise | fp16 | F1_RUNTIME | 5 |
| G | task-agnostic G | elementwise | fp32 | F1_COMPILE | 1 |
| G | task-agnostic G | elementwise | fp32 | F1_RUNTIME | 3 |
| G | task-agnostic G | elementwise | fp32 | None | 1 |
| G | task-agnostic G | matmul | bf16 | F0_PARSE | 1 |
| G | task-agnostic G | matmul | bf16 | F1_RUNTIME | 4 |
| G | task-agnostic G | matmul | fp16 | F1_RUNTIME | 5 |
| G | task-agnostic G | matmul | fp32 | F1_RUNTIME | 5 |
| G | task-agnostic G | reduction | bf16 | F1_RUNTIME | 5 |
| G | task-agnostic G | reduction | fp16 | F1_RUNTIME | 5 |
| G | task-agnostic G | reduction | fp32 | F1_RUNTIME | 5 |

## Metadata Completeness

| metadata_field | expected_rows | present | unknown | missing |
| --- | --- | --- | --- | --- |
| grammar_sha | 45 | 45 | 0 | 0 |
| gbnf_parse_valid | 45 | 45 | 0 | 0 |
| semantic_valid | 45 | 45 | 0 | 0 |
| grammar_valid | 45 | 45 | 0 | 0 |
| rejection_layer | 45 | 33 | 0 | 12 |
| stop_reason | 45 | 45 | 0 | 0 |
| xgrammar_version | 45 | 45 | 0 | 0 |
| transformers_version | 45 | 45 | 0 | 0 |
| tokenizers_version | 45 | 45 | 0 | 0 |
| model_revision | 45 | 45 | 0 | 0 |
| tokenizer_revision | 45 | 45 | 0 | 0 |
| modal_image_sha | 45 | 0 | 45 | 0 |
| modal_image_provenance_sha256 | 45 | 45 | 0 | 0 |
| modal_image_provenance_components | 45 | 45 | 0 | 0 |

## Grammar Rejections

| grammar_variant | kernel_class | dtype | rejection_layer | gbnf_parse_valid | semantic_valid | grammar_valid | failure_code | count |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| task-agnostic G | elementwise | fp16 | semantic_validator | true | false | false | F1_RUNTIME | 1 |
| task-agnostic G | elementwise | fp32 | semantic_validator | true | false | false | F1_RUNTIME | 2 |
| task-agnostic G | matmul | bf16 | gbnf_parse | false | false | false | F0_PARSE | 1 |
| task-agnostic G | matmul | bf16 | gbnf_parse | false | false | false | F1_RUNTIME | 2 |
| task-agnostic G | matmul | bf16 | semantic_validator | true | false | false | F1_RUNTIME | 2 |
| task-agnostic G | matmul | fp16 | gbnf_parse | false | false | false | F1_RUNTIME | 1 |
| task-agnostic G | matmul | fp16 | semantic_validator | true | false | false | F1_RUNTIME | 4 |
| task-agnostic G | matmul | fp32 | gbnf_parse | false | false | false | F1_RUNTIME | 1 |
| task-agnostic G | matmul | fp32 | semantic_validator | true | false | false | F1_RUNTIME | 4 |
| task-agnostic G | reduction | bf16 | gbnf_parse | false | false | false | F1_RUNTIME | 4 |
| task-agnostic G | reduction | bf16 | semantic_validator | true | false | false | F1_RUNTIME | 1 |
| task-agnostic G | reduction | fp16 | gbnf_parse | false | false | false | F1_RUNTIME | 5 |
| task-agnostic G | reduction | fp32 | gbnf_parse | false | false | false | F1_RUNTIME | 4 |
| task-agnostic G | reduction | fp32 | semantic_validator | true | false | false | F1_RUNTIME | 1 |

## Provenance Metadata

| metadata_field | value | count |
| --- | --- | --- |
| grammar_path | cluster1/grammar/triton_kernel_agnostic.gbnf | 45 |
| grammar_sha | 7896a1befca10f68ab6aa4521681fa2577eba6fb669e87daf622c15691a22e32 | 45 |
| modal_image_provenance_components | present | 45 |
| modal_image_provenance_sha256 | 82fb2024879bf2db36d75995b0704ade1a9c32dc2d3d3aff6207332995dc7535 | 45 |
| modal_image_sha | unknown | 45 |
| model_revision | 8e8ed243bbe6f9a5aff549a0924562fc719b2b8a | 45 |
| stop_reason | eos_token | 27 |
| stop_reason | max_new_tokens | 18 |
| tokenizer_revision | 8e8ed243bbe6f9a5aff549a0924562fc719b2b8a | 45 |
| tokenizers_version | 0.21.1 | 45 |
| transformers_version | 4.47.1 | 45 |
| xgrammar_version | 0.1.33 | 45 |

## Compile Error Types

| condition | grammar_variant | kernel_class | dtype | compile_error_type | count |
| --- | --- | --- | --- | --- | --- |
| G | task-agnostic G | elementwise | bf16 | RuntimeError | 5 |
| G | task-agnostic G | elementwise | fp16 | RuntimeError | 5 |
| G | task-agnostic G | elementwise | fp32 | CompilationError | 1 |
| G | task-agnostic G | elementwise | fp32 | None | 1 |
| G | task-agnostic G | elementwise | fp32 | RuntimeError | 3 |
| G | task-agnostic G | matmul | bf16 | RuntimeError | 4 |
| G | task-agnostic G | matmul | bf16 | SignatureError | 1 |
| G | task-agnostic G | matmul | fp16 | RuntimeError | 5 |
| G | task-agnostic G | matmul | fp32 | RuntimeError | 5 |
| G | task-agnostic G | reduction | bf16 | RuntimeError | 5 |
| G | task-agnostic G | reduction | fp16 | RuntimeError | 5 |
| G | task-agnostic G | reduction | fp32 | RuntimeError | 5 |

## Grammar Acceptance

| condition | grammar_variant | kernel_class | dtype | n | grammar_valid | gbnf_parse_valid_rate | semantic_valid_rate |
| --- | --- | --- | --- | --- | --- | --- | --- |
| G | task-agnostic G | elementwise | bf16 | 5 | 1.000000 | 1.000000 | 1.000000 |
| G | task-agnostic G | elementwise | fp16 | 5 | 0.800000 | 1.000000 | 0.800000 |
| G | task-agnostic G | elementwise | fp32 | 5 | 0.600000 | 1.000000 | 0.600000 |
| G | task-agnostic G | matmul | bf16 | 5 | 0.000000 | 0.400000 | 0.000000 |
| G | task-agnostic G | matmul | fp16 | 5 | 0.000000 | 0.800000 | 0.000000 |
| G | task-agnostic G | matmul | fp32 | 5 | 0.000000 | 0.800000 | 0.000000 |
| G | task-agnostic G | reduction | bf16 | 5 | 0.000000 | 0.200000 | 0.000000 |
| G | task-agnostic G | reduction | fp16 | 5 | 0.000000 | 0.000000 | 0.000000 |
| G | task-agnostic G | reduction | fp32 | 5 | 0.000000 | 0.200000 | 0.000000 |

## Rejection Layer Breakdown

| grammar_variant | kernel_class | dtype | rejection_layer | count |
| --- | --- | --- | --- | --- |
| task-agnostic G | elementwise | bf16 | accepted | 5 |
| task-agnostic G | elementwise | fp16 | accepted | 4 |
| task-agnostic G | elementwise | fp16 | semantic_validator | 1 |
| task-agnostic G | elementwise | fp32 | accepted | 3 |
| task-agnostic G | elementwise | fp32 | semantic_validator | 2 |
| task-agnostic G | matmul | bf16 | gbnf_parse | 3 |
| task-agnostic G | matmul | bf16 | semantic_validator | 2 |
| task-agnostic G | matmul | fp16 | gbnf_parse | 1 |
| task-agnostic G | matmul | fp16 | semantic_validator | 4 |
| task-agnostic G | matmul | fp32 | gbnf_parse | 1 |
| task-agnostic G | matmul | fp32 | semantic_validator | 4 |
| task-agnostic G | reduction | bf16 | gbnf_parse | 4 |
| task-agnostic G | reduction | bf16 | semantic_validator | 1 |
| task-agnostic G | reduction | fp16 | gbnf_parse | 5 |
| task-agnostic G | reduction | fp32 | gbnf_parse | 4 |
| task-agnostic G | reduction | fp32 | semantic_validator | 1 |

## Stop Reason Breakdown

| condition | grammar_variant | kernel_class | dtype | stop_reason | count |
| --- | --- | --- | --- | --- | --- |
| G | task-agnostic G | elementwise | bf16 | eos_token | 5 |
| G | task-agnostic G | elementwise | fp16 | eos_token | 5 |
| G | task-agnostic G | elementwise | fp32 | eos_token | 5 |
| G | task-agnostic G | matmul | bf16 | eos_token | 2 |
| G | task-agnostic G | matmul | bf16 | max_new_tokens | 3 |
| G | task-agnostic G | matmul | fp16 | eos_token | 4 |
| G | task-agnostic G | matmul | fp16 | max_new_tokens | 1 |
| G | task-agnostic G | matmul | fp32 | eos_token | 4 |
| G | task-agnostic G | matmul | fp32 | max_new_tokens | 1 |
| G | task-agnostic G | reduction | bf16 | eos_token | 1 |
| G | task-agnostic G | reduction | bf16 | max_new_tokens | 4 |
| G | task-agnostic G | reduction | fp16 | max_new_tokens | 5 |
| G | task-agnostic G | reduction | fp32 | eos_token | 1 |
| G | task-agnostic G | reduction | fp32 | max_new_tokens | 4 |

## Null-Hypothesis Report

- `kernel_class=elementwise`, `dtype=bf16`: comparison requires both baseline and grammar-active rows; observed 1 condition group(s).
- `kernel_class=elementwise`, `dtype=fp16`: comparison requires both baseline and grammar-active rows; observed 1 condition group(s).
- `kernel_class=elementwise`, `dtype=fp32`: comparison requires both baseline and grammar-active rows; observed 1 condition group(s).
- `kernel_class=matmul`, `dtype=bf16`: comparison requires both baseline and grammar-active rows; observed 1 condition group(s).
- `kernel_class=matmul`, `dtype=fp16`: comparison requires both baseline and grammar-active rows; observed 1 condition group(s).
- `kernel_class=matmul`, `dtype=fp32`: comparison requires both baseline and grammar-active rows; observed 1 condition group(s).
- `kernel_class=reduction`, `dtype=bf16`: comparison requires both baseline and grammar-active rows; observed 1 condition group(s).
- `kernel_class=reduction`, `dtype=fp16`: comparison requires both baseline and grammar-active rows; observed 1 condition group(s).
- `kernel_class=reduction`, `dtype=fp32`: comparison requires both baseline and grammar-active rows; observed 1 condition group(s).
