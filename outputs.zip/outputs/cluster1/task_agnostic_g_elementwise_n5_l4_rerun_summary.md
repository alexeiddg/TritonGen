# Cluster 1 Compile-Only Summary

## Run Shape

row_count: 15
actual_cells: 3
expected_row_count: 15
expected_conditions: ['G']
actual_conditions: ['G']
expected_grammar_variants: ['task_agnostic']
actual_grammar_variants: ['task_agnostic']
expected_kernel_classes: ['elementwise']
actual_kernel_classes: ['elementwise']
expected_dtypes: ['fp32', 'fp16', 'bf16']
actual_dtypes: ['bf16', 'fp16', 'fp32']
missing_cells: 0
unexpected_cells: 0
duplicate_identities: 0

## Compile Metrics

compile_success_scope: all_dtype_strict

| condition | grammar_variant | kernel_class | dtype | n | compile_success_scope | compile_successes | compile_failures | compile@1 | prompt_dtype_compile_successes | prompt_dtype_compile_failures | prompt_dtype_compile_success_rate | pass@1 | pass@5 | pass@10 | unique_solution_rate |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| G | task_agnostic | elementwise | bf16 | 5 | all_dtype_strict | 0 | 5 | 0.000000 | 4 | 1 | 0.800000 | 0.000000 | 0.000000 | NA | 0.600000 |
| G | task_agnostic | elementwise | fp16 | 5 | all_dtype_strict | 0 | 5 | 0.000000 | 1 | 4 | 0.200000 | 0.000000 | 0.000000 | NA | 1.000000 |
| G | task_agnostic | elementwise | fp32 | 5 | all_dtype_strict | 1 | 4 | 0.200000 | 1 | 4 | 0.200000 | 0.200000 | 1.000000 | NA | 1.000000 |

## Masked Token Rate

| condition | grammar_variant | kernel_class | dtype | n | mean | min | max |
| --- | --- | --- | --- | --- | --- | --- | --- |
| G | task_agnostic | elementwise | bf16 | 5 | 0.799088 | 0.795368 | 0.800702 |
| G | task_agnostic | elementwise | fp16 | 5 | 0.799170 | 0.796133 | 0.801827 |
| G | task_agnostic | elementwise | fp32 | 5 | 0.830963 | 0.794813 | 0.846688 |

## Compile Error Types

| condition | grammar_variant | kernel_class | dtype | compile_error_type | count |
| --- | --- | --- | --- | --- | --- |
| G | task_agnostic | elementwise | bf16 | RuntimeError | 5 |
| G | task_agnostic | elementwise | fp16 | RuntimeError | 5 |
| G | task_agnostic | elementwise | fp32 | CompilationError | 1 |
| G | task_agnostic | elementwise | fp32 | None | 1 |
| G | task_agnostic | elementwise | fp32 | RuntimeError | 3 |

## Null-Hypothesis Report

- `kernel_class=elementwise`, `dtype=bf16`: comparison requires both baseline and G rows; observed 1 condition group(s).
- `kernel_class=elementwise`, `dtype=fp16`: comparison requires both baseline and G rows; observed 1 condition group(s).
- `kernel_class=elementwise`, `dtype=fp32`: comparison requires both baseline and G rows; observed 1 condition group(s).
